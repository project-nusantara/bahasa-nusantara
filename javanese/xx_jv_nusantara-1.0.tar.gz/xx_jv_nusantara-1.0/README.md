| Feature | Description |
| --- | --- |
| **Name** | `xx_xx_jv_nusantara` |
| **Version** | `1.0` |
| **spaCy** | `>=3.6.1,<3.7.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `morphologizer`, `parser`, `trainable_lemmatizer` |
| **Components** | `tok2vec`, `tagger`, `morphologizer`, `parser`, `trainable_lemmatizer` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (228 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `ADJ`, `ADJ_DET`, `ADJ_PART`, `ADJ_PRON`, `ADP`, `ADP_PRON`, `ADV`, `AUX`, `AUX_PRON`, `CCONJ`, `DET`, `DET_DET`, `INTJ`, `NOUN`, `NOUN_ADP`, `NOUN_DET`, `NOUN_PRON`, `NOUN_PUNCT_PRON`, `NUM`, `NUM_DET`, `NUM_NOUN`, `PART`, `PART_ADJ`, `PART_AUX`, `PRON`, `PRON_PRON`, `PRON_VERB`, `PRON_VERB_DET`, `PROPN`, `PROPN_DET`, `PROPN_PRON`, `PUNCT`, `Polite=Form`, `SCONJ`, `SYM`, `VERB`, `VERB_DET`, `VERB_PRON`, `X`, `X_DET`, `X_PRON` |
| **`morphologizer`** | `Number=Sing\|POS=NOUN\|Polite=Infm`, `POS=DET\|Polite=Infm\|PronType=Dem`, `Mood=Ind\|POS=VERB\|Voice=Act`, `POS=PRON\|Polite=Infm\|PronType=Rel`, `POS=ADJ`, `POS=PUNCT`, `POS=ADP\|Polite=Infm`, `Number=Sing\|POS=NOUN`, `POS=ADV`, `POS=PROPN`, `Number=Sing\|POS=NOUN\|Person=3\|Polite=Infm\|PronType=Prs`, `POS=CCONJ\|Polite=Infm`, `POS=PART\|Polarity=Neg\|Polite=Infm`, `POS=SCONJ\|Polite=Infm`, `POS=AUX\|Polite=Infm`, `Mood=Ind\|POS=VERB\|Polite=Infm\|Voice=Act`, `POS=ADV\|Polite=Infm`, `POS=SCONJ`, `Number=Sing\|POS=PRON\|Person=2\|Polite=Infm\|PronType=Prs`, `POS=ADV\|Polite=Infm\|PronType=Dem`, `Mood=Ind\|POS=VERB\|Voice=Pass`, `Mood=Ind\|POS=VERB\|Polite=Elev\|Voice=Act`, `POS=ADP`, `Foreign=Yes\|POS=X`, `Mood=Ind\|POS=VERB\|Polite=Form\|Voice=Act`, `Number=Sing\|POS=PRON\|Person=1\|Polite=Infm\|PronType=Prs`, `Number=Sing\|POS=PRON\|Person=3\|Polite=Infm\|PronType=Prs`, `Mood=Irr\|POS=VERB\|Polite=Infm\|Voice=Pass`, `POS=PART`, `Mood=Ind\|POS=VERB\|Polite=Infm\|Voice=Pass`, `Mood=Irr\|POS=VERB\|Voice=Pass`, `Number=Sing\|POS=NOUN\|Person=2\|Polite=Infm\|PronType=Prs`, `Definite=Def\|Number=Sing\|POS=NOUN\|Polite=Infm\|PronType=Art`, `POS=INTJ`, `Mood=Imp\|POS=VERB\|Polite=Infm\|Voice=Act`, `Mood=Imp\|POS=VERB\|Voice=Act`, `POS=PRON\|Polite=Infm\|PronType=Tot`, `NumType=Card\|POS=NUM\|Polite=Infm`, `POS=ADV\|Polite=Infm\|PronType=Int`, `Abbr=Yes\|POS=DET\|Polite=Infm\|PronType=Dem`, `POS=PART\|Polite=Infm`, `Number=Sing\|POS=NOUN\|Person=1\|Polite=Infm\|PronType=Prs`, `POS=ADJ\|Polite=Infm`, `Mood=Ind\|Number=Sing\|POS=VERB\|Person=1\|Polite=Infm\|PronType=Prs\|Voice=Act`, `POS=PRON\|PronType=Dem`, `Definite=Def\|Mood=Ind\|Number=Sing\|POS=VERB\|Person=1\|Polite=Infm\|PronType=Art,Prs\|Voice=Act`, `Mood=Ind\|Number=Sing\|POS=VERB\|Person=2\|Polite=Infm\|PronType=Prs\|Voice=Act`, `Mood=Ind\|POS=VERB\|Polite=Form\|Voice=Pass`, `Definite=Def\|POS=DET\|Polite=Form\|PronType=Art`, `Number=Sing\|POS=NOUN\|Person=3\|Polite=Elev,Infm\|PronType=Prs`, `Number=Plur\|POS=PRON\|Person=1\|Polite=Infm\|PronType=Prs`, `Definite=Def\|NumType=Card\|POS=NUM\|Polite=Infm\|PronType=Art`, `Number=Sing\|POS=NOUN\|Typo=Yes`, `POS=X`, `Definite=Def\|Number=Plur\|POS=DET\|PronType=Art`, `Number=Sing\|POS=NOUN\|Polite=Elev`, `POS=AUX\|Polite=Form`, `POS=DET\|Polite=Infm\|PronType=Tot`, `Number=Plur\|POS=NOUN`, `Number=Plur\|POS=NOUN\|Polite=Infm`, `Number=Sing\|POS=PRON\|Person=3\|Polite=Form\|PronType=Prs`, `Number=Sing\|POS=NOUN\|Polite=Form`, `Number=Sing\|POS=ADJ\|Person=3\|Polite=Form,Infm\|PronType=Prs`, `POS=PART\|Polarity=Neg\|Polite=Form`, `POS=ADV\|Polite=Form\|PronType=Dem`, `POS=ADP\|Polite=Form`, `POS=PRON\|Polite=Form\|PronType=Rel`, `POS=DET\|Polite=Form\|PronType=Dem`, `POS=ADJ\|Polite=Form`, `POS=ADV\|Polite=Form`, `POS=CCONJ\|Polite=Form`, `Number=Sing\|POS=NOUN\|Person=3\|Polite=Form\|PronType=Prs`, `Definite=Def\|POS=ADJ\|Polite=Form\|PronType=Art`, `POS=INTJ\|Polite=Form`, `POS=PRON\|Polite=Form\|PronType=Dem`, `Definite=Def\|POS=NOUN\|Polite=Form\|PronType=Art`, `Number=Plur\|POS=DET\|PronType=Ind`, `Number=Plur\|POS=NOUN\|Polite=Form`, `POS=SCONJ\|Polite=Form`, `Definite=Def\|Number=Sing\|POS=NOUN\|Polite=Form\|PronType=Art`, `POS=PRON\|Polite=Infm\|PronType=Int`, `Definite=Def\|Mood=Ind\|POS=VERB\|Polite=Infm\|PronType=Art\|Voice=Act`, `POS=DET\|Polite=Infm\|PronType=Emp`, `Number=Sing\|POS=ADJ\|Person=3\|Polite=Infm\|PronType=Prs`, `Number=Plur\|POS=PRON\|PronType=Ind`, `Definite=Def\|POS=ADJ\|Polite=Infm\|PronType=Art`, `POS=PRON\|Polite=Infm\|PronType=Dem`, `Number=Sing\|POS=PRON\|Person=3\|Polite=Elev\|PronType=Prs`, `Mood=Ind\|POS=VERB\|Polite=Humb\|Voice=Act`, `POS=DET\|Polite=Infm`, `Number=Sing\|POS=PRON\|Person=1\|Polite=Form\|PronType=Prs`, `NumType=Card\|POS=NUM`, `Definite=Def\|Mood=Ind\|POS=VERB\|Polite=Form\|PronType=Art\|Voice=Pass`, `Number=Sing\|POS=PRON\|Person=2\|Polite=Form\|PronType=Prs`, `POS=ADP\|Polite=Elev`, `Number=Sing\|POS=PRON\|Person=3\|Polite=Infm\|PronType=Prs\|Reflex=Yes`, `NumType=Ord\|POS=ADJ\|Polite=Form`, `Number=Plur\|POS=DET\|Polite=Form\|PronType=Ind`, `Abbr=Yes\|POS=AUX\|Polite=Infm`, `Foreign=Yes\|Number=Sing\|POS=X\|Person=3\|Polite=Infm\|PronType=Prs`, `Definite=Ind\|Number=Sing\|POS=DET\|Polite=Infm\|PronType=Art`, `Number=Plur,Sing\|POS=NOUN\|Person=3\|Polite=Infm\|PronType=Prs`, `NumType=Card\|POS=NUM\|Polite=Form`, `NumType=Ord\|POS=ADJ\|Polite=Infm`, `Definite=Def\|Foreign=Yes\|POS=X\|Polite=Form\|PronType=Art`, `NumType=Ord\|POS=ADJ`, `Definite=Def\|Mood=Ind\|POS=VERB\|Polite=Elev,Form\|PronType=Art\|Voice=Act`, `POS=SYM`, `Number=Plur\|POS=DET\|Polite=Infm\|PronType=Ind`, `POS=SCONJ\|Polite=Elev`, `POS=DET\|Polite=Form\|PronType=Tot`, `POS=DET\|Polite=Form\|PronType=Emp`, `Definite=Def\|POS=DET\|Polite=Infm\|PronType=Art`, `Foreign=Yes\|Number=Sing\|POS=X\|Person=3\|Polite=Form\|PronType=Prs`, `Definite=Def\|Foreign=Yes\|POS=X\|Polite=Infm\|PronType=Art`, `POS=ADV\|PronType=Int`, `Definite=Ind\|POS=DET\|PronType=Art`, `Number=Sing\|POS=ADJ\|Person=3\|Polite=Form\|PronType=Prs`, `Definite=Def\|POS=PROPN\|Polite=Infm\|PronType=Art`, `POS=ADV\|PronType=Tot`, `POS=PRON\|Polite=Form`, `POS=CCONJ`, `Number=Plur\|POS=DET`, `Mood=Ind\|Number=Sing\|POS=VERB\|Person=3\|Polite=Infm\|PronType=Prs\|Voice=Act`, `POS=PRON\|PronType=Prs\|Reflex=Yes`, `POS=NUM\|Polite=Infm`, `POS=PRON\|PronType=Rel`, `Number=Sing\|POS=NOUN\|Polite=Form,Infm`, `Definite=Def\|Mood=Ind\|POS=VERB\|Polite=Infm\|PronType=Art\|Voice=Pass`, `POS=PRON\|Polite=Infm`, `Abbr=Yes\|POS=ADJ\|Polarity=Neg\|Polite=Infm`, `POS=ADV\|Polite=Form\|PronType=Rel`, `POS=ADV\|PronType=Dem`, `POS=INTJ\|Polite=Humb`, `POS=DET\|PronType=Dem`, `Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `Abbr=Yes\|POS=ADV\|PronType=Int`, `Abbr=Yes\|POS=PART\|Polarity=Neg\|Polite=Infm`, `POS=ADV\|Polite=Infm\|PronType=Rel`, `Definite=Def\|Number=Sing\|POS=NOUN\|Polite=Form,Infm\|PronType=Art`, `Definite=Def\|Mood=Ind\|POS=VERB\|Polite=Form,Infm\|PronType=Art\|Voice=Act`, `POS=X\|Typo=Yes`, `Number=Sing\|POS=AUX\|Person=1\|Polite=Infm\|PronType=Prs`, `Number=Sing\|POS=PROPN\|Person=2\|Polite=Infm\|PronType=Prs`, `Number=Sing\|POS=ADJ\|Person=1\|Polite=Infm\|PronType=Prs`, `Abbr=Yes\|POS=PRON\|Polite=Infm\|PronType=Dem`, `Definite=Def\|Number=Sing\|POS=DET\|Polite=Infm\|PronType=Art`, `POS=PRON`, `Number=Sing\|POS=NOUN\|Person=1\|Polite=Form,Infm\|PronType=Prs`, `POS=ADV\|Polite=Elev`, `POS=DET\|PronType=Tot`, `Mood=Ind\|Number=Sing\|POS=VERB\|Person=1\|Polite=Form,Infm\|PronType=Prs\|Voice=Act`, `Number=Plur,Sing\|POS=NOUN\|Person=1\|Polite=Infm\|PronType=Prs`, `POS=DET`, `POS=VERB\|Polite=Infm\|Voice=Act`, `POS=NOUN\|Polite=Infm`, `NumType=Card\|Number=Sing\|POS=NOUN\|Polite=Infm`, `POS=AUX` |
| **`parser`** | `ROOT`, `acl`, `acl:relcl`, `advcl`, `advmod`, `amod`, `appos`, `aux`, `case`, `cc`, `conj`, `cop`, `dep`, `det`, `flat`, `flat:name`, `mark`, `nmod`, `nmod:lmod`, `nmod:poss`, `nsubj`, `nsubj:pass`, `nummod`, `obj`, `obl`, `obl:tmod`, `parataxis`, `punct`, `xcomp` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 85.56 |
| `POS_ACC` | 86.86 |
| `MORPH_ACC` | 85.42 |
| `DEP_UAS` | 73.46 |
| `DEP_LAS` | 59.02 |
| `SENTS_P` | 88.46 |
| `SENTS_R` | 92.00 |
| `SENTS_F` | 90.20 |
| `LEMMA_ACC` | 55.89 |
| `TOK2VEC_LOSS` | 499558.79 |
| `TAGGER_LOSS` | 23586.06 |
| `MORPHOLOGIZER_LOSS` | 22126.78 |
| `PARSER_LOSS` | 1135196.47 |
| `TRAINABLE_LEMMATIZER_LOSS` | 12394.97 |